import R from "./ramda.js";
/**
 * khet.js is a module t0 play "Khet 2.0".
 * https://en.wikipedia.org/wiki/Khet_(game)
 * @namespace Khet
 * @author Christian Grose
 * @version 2023
 */

const Khet = Object.create(null);

/**
 * A board is an 2 dimensional grid containing {@link Khet.Piece}s.
 * It is an array of rows.
 * @memberof Khet
 * @typedef {Array} Board
 */

/**
*
* <b>Each piece corresponds to an array containing:
* * Direction
* * Type
* * Colour of the piece </b>
*
* e.g.
* *   [3, 2, 1] = red sphinx pointing downwards
* *   [0, 5, 0] = blue pyramid pointing right
* *   [1, 3, 0] = blue anubis pointing upwards
*
* <b>Piece types:</b>
* *   Empty: 0
* *   Pharoh: 1
* *   Sphinx: 2
* *   Anubis: 3
* *   Scarab: 4
* *   Pyramid: 5
*
* <b>Going further into direction:</b>
* For standard pieces without diagonal orientation:
* *   0: Right
* *   1: Up
* *   2: Lest
* *   3: Down
* For pieces where the orientation is ambiguous (Pyramid & Scarab):
* *   0: ◣ (Pyramid), \ (Scarab)
* *   1: ◢, /
* *   2: ◥, \
* *   3: ◤, /
* @memberof Khet
* @typedef {Array} Piece
*/

const game_rows = 8;
const game_columns = 10;

const controlPanelRows = 3;
const controlPanelColumns = 3;

const currentPlayer = 1;

// document.documentElement.style.setProperty("--game-rows", game_rows);
// document.documentElement.style.setProperty("--game-columns", game_columns);

// const game_board = document.getElementById("game_board");
// const control_panel = document.getElementById("control_panel");
// const feedback = document.getElementById("feedback");

/**
 * Creates a new empty board.
 * Optionally with a specified width and height,
 * otherwise returns a standard 8 wide, 10 high board.
 * @memberof Khet
 * @function
 * @param {number} [width = 8] The width of the new board.
 * @param {number} [height = 10] The height of the new board.
 * @returns {Khet.emptyBoard} An empty board for starting a game.
 */
Khet.getEmptyBoard = function (width = 10, height = 8) {
  const emptyBoard = [
      [
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ]
      ],
      [
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ]
      ],
      [
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ]
      ],
      [
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ]
      ],
      [
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ]
      ],
      [
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ]
      ],
      [
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ]
      ],
      [
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ],
        [ 0, 0, 0 ], [ 0, 0, 0 ]
      ]
  ];
  // I did try to create an empty array but it wasnt happening :(
  // R.repeat causes issues later on in the code
  // Some attempts below:

  // const emptyBoard = [];
  // for (let i = 0; i < height; i++) {
  //   for (let i = 0; i < width; i++) {
  //     for (let i = 0; i < 5; i++) {
  //       emptyBoard[i].push(0);
  //     }
  //   }
  // }
  // console.log(emptyBoard)

  // const emptyBoard = R.repeat(R.repeat(R.repeat(0, 3), width), height);
  // console.log(emptyBoard)
  // const clonedEmptyBoard = [...emptyBoard];
  // console.log(clonedEmptyBoard);
  return emptyBoard;
};

/**
 * Gets the classic board for Khet.
 * @memberof Khet
 * @function
 * @param {Array} array The array to initialize the board with,
 * typicallly the empty board.
 * @returns {Array} The classic board.
 */
Khet.getClassicBoard = function (array) {
  const classicBoard = array;
  classicBoard[0][0] = [3, 2, 1];
  classicBoard[0][4] = [3, 3, 1];
  classicBoard[0][5] = [1, 1, 1];
  classicBoard[0][6] = [3, 3, 1];
  classicBoard[0][7] = [3, 5, 1];

  classicBoard[1][2] = [2, 5, 1];

  classicBoard[2][3] = [1, 5, 0];
 
  classicBoard[3][0] = [0, 5, 1];
  classicBoard[3][2] = [2, 5, 0];
  classicBoard[3][4] = [1, 4, 1];
  classicBoard[3][5] = [0, 4, 1];
  classicBoard[3][7] = [3, 5, 1];
  classicBoard[3][9] = [1, 5, 0];
  
  classicBoard[4][0] = [3, 5, 1];
  classicBoard[4][2] = [1, 5, 0];
  classicBoard[4][4] = [0, 4, 1];
  classicBoard[4][5] = [1, 4, 1];
  classicBoard[4][7] = [0, 5, 1];
  classicBoard[4][9] = [2, 5, 0];

  classicBoard[5][6] = [3, 5, 1];

  classicBoard[6][7] = [0, 5, 0];

  classicBoard[7][2] = [1, 5, 0];
  classicBoard[7][3] = [1, 3, 0];
  classicBoard[7][4] = [1, 1, 0];
  classicBoard[7][5] = [1, 3, 0];
  classicBoard[7][9] = [1, 2, 0];

  return classicBoard;
};

const getImages = function () {
  // Array of image files, colour -> type -> direction
  const images = [
    [
      ["assets/000.png"], 
      ["assets/010.png", "assets/110.png", "assets/210.png", "assets/310.png"],
      ["assets/020.png", "assets/120.png", "assets/220.png", "assets/320.png"],
      ["assets/030.png", "assets/130.png", "assets/230.png", "assets/330.png"], 
      ["assets/040.png", "assets/140.png", "assets/240.png", "assets/340.png"],
      ["assets/050.png", "assets/150.png", "assets/250.png", "assets/350.png"]
    ],
    [
      ["assets/000.png"],
      ["assets/011.png", "assets/111.png", "assets/211.png", "assets/311.png"],
      ["assets/021.png", "assets/121.png", "assets/221.png", "assets/321.png"],
      ["assets/031.png", "assets/131.png", "assets/231.png", "assets/331.png"],
      ["assets/041.png", "assets/141.png", "assets/241.png", "assets/341.png"],
      ["assets/051.png", "assets/151.png", "assets/251.png", "assets/351.png"]
    ]
  ];
  return images;
};

/**
* Gets a new board with icon asset paths to represent each {@link Khet.Piece}
* @memberof Khet
* @function
* @param {Array} board The input board conataining {@link Khet.Piece}s.
* @returns {Array} Returns a board with icon asset paths.
*/
Khet.getImageArray = function (board) {
  console.log(board);
  const imageArray = R.map(function(row, y){
    return R.map(function(piece, x){
        const colour = piece[2];
        const type = piece[1];
        const direction = piece[0];
        // console.log(colour)
        const path = getImages()[colour][type][direction];
        return path;
      }, row);
  }, board);
  return imageArray;
};

/**
* Gets a new panel with icon asset paths to represent each command.
* @memberof Khet
* @function
* @returns {(Array)} Returns a panel array with icon asset paths.
*/
Khet.getControlImageArray = function(){
  const images = [
      [
        "assets/1.png",
        "assets/2.png",
        "assets/3.png",
      ],
      [
        "assets/4.png",
        "assets/5.png",
        "assets/6.png",
      ],
      [
        "assets/7.png",
        "assets/8.png",
        "assets/9.png",
      ]
  ]
  return images;
}

/*
 Empty board with r & b used to denote squares
 where only red & blue pieces can be.
*/
const r = "r";
const b = "b";
const check_board=[
    [r, b, 0, 0, 0, 0, 0, 0, r, b],
    [r, 0, 0, 0, 0, 0, 0, 0, 0, b],
    [r, 0, 0, 0, 0, 0, 0, 0, 0, b],
    [r, 0, 0, 0, 0, 0, 0, 0, 0, b],
    [r, 0, 0, 0, 0, 0, 0, 0, 0, b],
    [r, 0, 0, 0, 0, 0, 0, 0, 0, b],
    [r, 0, 0, 0, 0, 0, 0, 0, 0, b],
    [r, b, 0, 0, 0, 0, 0, 0, r, b]
];

// Returns the starting situation for the laser depending on the player.
const getInitialLaserStatus = function(player, board) {
    if (player === "red") {
      const laser1 = {
        position: [0,0],
        direction: board[0][0][0],
        alive: true
      };
    return laser1;
    }
    else if (player === "blue") {
      const laser2 = {
        position: [7,9],
        direction: board[7][9][0],
        alive: true
      };
    return laser2;
    }
    return undefined;
};

const moveLaser = function (direction, currentPos) {
  switch (direction) {
    case 0:
      currentPos = [currentPos[0], currentPos[1]+1];
      break;
    case 1:
      currentPos = [currentPos[0]-1, currentPos[1]];
      break;
    case 2:
      currentPos = [currentPos[0], currentPos[1]-1];
      break;
    case 3:
      currentPos = [currentPos[0]+1, currentPos[1]];
      break;
  }
return currentPos;
};

/**
* Checks if a coordinate is on the board.
* @memberof Khet
* @function
* @param {Array} currentPos Input coordinate as a 2D array (row, column).
* @returns {Boolean} Returns true if the coordinate on the board, false if not.
*/
Khet.getOnBoardStatus = function(currentPos){
  if (currentPos[0] < 0 || currentPos[0] >= game_rows) {
    return false;
  }
  else if (currentPos[1] < 0 || currentPos[1] >= game_columns) {
    return false;
  }
  return true;
};

/*
Takes the new position and returns whether the laser is still alive or not.

For pieces where the orientation is ambiguous (Pyramid & Scarab):
    0: ◣ (Pyramid), \ (Scarab)
    1: ◢, /
    2: ◥, \
    3: ◤, /
*/
const getLaserStatus = function(direction, currentPos, board) {

    // Gets the type of the piece on the board at the new position of the laser.
    const occupying_piece_type = board[currentPos[0]][currentPos[1]][1];
    const occupying_piece_direction = board[currentPos[0]][currentPos[1]][0];
    switch (occupying_piece_type) {
      // If empty, laser stays alive.
      case 0:
        return true;
      // If Pharoh, laser dies.
      case 1:
        return false;
      // If Sphinx, laser dies.
      case 2:
        return false;
      // If Anubis, laser dies.
      case 3:
        return false;
      // If Scarab, laser stays alive.
      case 4:
        return true;
      // If Pyramid, laser stays alive if the laser direction hits the mirror surface.
      case 5:
        // If laser comes in from left:
        if (direction === 0){
          // If 1: ◢ or 2: ◥, the laser is reflected and therefore stays alive, if not it dies.
          return (occupying_piece_direction === 1 || occupying_piece_direction === 2);
        }
        // Laser from top:
        else if (direction === 3){
          // If  1: ◢ or 0: ◣ , the laser is reflected and therefore stays alive, if not it dies.
          return (occupying_piece_direction === 0 || occupying_piece_direction === 1);
        }
        // Laser from the right:
        else if (direction === 2){
          // If  0: ◣ or 3: ◤, the laser is reflected and therefore stays alive, if not it dies.
          return (occupying_piece_direction === 0 || occupying_piece_direction === 3);
        }
       // Laser from the underneath:
        else if (direction === 1){
          // If 2: ◥ or 3: ◤, the laser is reflected and therefore stays alive, if not it dies.
          return (occupying_piece_direction === 2 || occupying_piece_direction === 3);
        }
      // If laser has gone off the board the input direction will be undefined and is therefore dead. 
      default:
        return false;
      }
};

/*
Takes the new piece and directiion and returns the new laser direction as a number.

For pieces where the orientation is ambiguous (Pyramid & Scarab):
    0: ◣ (Pyramid), \ (Scarab)
    1: ◢, /
    2: ◥, \
    3: ◤, /
*/
 const updateDirection = function(direction, currentPos, board) {
  // Gets the type of the piece on the board at the new position of the laser.
  const occupying_piece_type = board[currentPos[0]][currentPos[1]][1];
  const occupying_piece_direction = board[currentPos[0]][currentPos[1]][0];
  switch (occupying_piece_type) {
    // If empty, the new laser direction stays the same.
    case 0:
      return direction;
    // If Scarab, the new laser direction depends on the incoming direction and the orientation of the Scarab.
    case 4:
      // If laser comes in from left:
      if (direction === 2){
        // If 1: / or 3: /, the laser is reflected up.
        if  (occupying_piece_direction === 1 || occupying_piece_direction === 3){
          return 1;
        }
        // Else laser is reflected down:
        return 3;
      }
      // Laser from top:
      else if (direction === 3){
        // If 1: / or 3: /, the laser is reflected left.
        if  (occupying_piece_direction === 1 || occupying_piece_direction === 3){
          return 2;
        }
        // Else laser is reflected right:
        return 0;
      }
      // Laser from the right:
      else if (direction === 0){
        // If 1: / or 3: /, the laser is reflected down.
        if  (occupying_piece_direction === 1 || occupying_piece_direction === 3){
          return 3;
        }
          // Else laser is reflected up:
        return 1;
      }
      // Laser from the underneath:
      else if (direction === 1){
        // If 1: / or 3: /, the laser is reflected right.
        if  (occupying_piece_direction === 1 || occupying_piece_direction === 3){
          return 0;
        }
        // Else laser is reflected left:
        return 2;
      }
    // If Pyramid, laser is reflected depending on the incoming direction
    case 5:
      // If laser comes in from left:
      if (direction === 0){
        // If 1: ◢, the laser is reflected up.
        if  (occupying_piece_direction === 1){
          return 1;
        }
        // Else laser is reflected down:
        return 3;
      }
      // Laser from top:
      else if (direction === 3){
        // If 1: ◢, the laser is reflected left.
        if  (occupying_piece_direction === 1){
          return 2;
        }
        // Else laser is reflected right:
        return 0;
      }
      // Laser from the right:
      else if (direction === 2){
        // If 3: ◤, the laser is reflected down.
        if  (occupying_piece_direction === 3){
          return 3;
        }
          // Else laser is reflected up:
        return 1;
      }
      // Laser from the underneath:
      else if (direction === 1){
        // If 3: ◤, the laser is reflected right.
        if  (occupying_piece_direction === 3){
          return 0;
        }
        // Else laser is reflected left:
        return 2;
      }
  }
};

/**
* Gets the end coordinate of the laser based on the player firing
* and the board position.
* @memberof Khet
* @function
* @param {String} player The player firing the laser, "red" or "blue",
* this effects which sphinx fires the laser
* @param {Array} board {@link Board}
* @returns {Array} Coordinate of the laser endpoint as a 2D array (row, column).
*/
Khet.getLaserEndPoint = function(player, board) {
    // Sets up the returned array
    let laserOutputArray = [];
    // Returns the initial laser object using the player specified.
    let laser = getInitialLaserStatus(player, board);

    // Pushes the initial position to the array
    const initialPos = laser.position;
    laserOutputArray.push(initialPos);
    // Sets up the current position of laser as the initial posistion.
    let currentPos = initialPos;
    
    while (laser.alive) {
      // Finds out the next position using the move function.
      currentPos = moveLaser(laser.direction, currentPos);
      // Pushes this new position onto the output array.
      laserOutputArray.push(currentPos);
      if (Khet.getOnBoardStatus(currentPos)) {
        // Checks if laser is still alive at this new postion, returns true or false.
        laser.alive = getLaserStatus(laser.direction, currentPos, board);
        laser.direction = updateDirection(laser.direction, currentPos, board);
      } else {
        laser.alive = false;
      }

      /* If the laser is still alive after the check
         it returns the new direction and sets the laser to it.
      */
    }
    // console.log(laserOutputArray);
    //return an array of every position that has the laser has been.
    return laserOutputArray[laserOutputArray.length-1];
};

/**
* Gets the end direction of the laser based on the player firing
* and the board position. It is used for calculating edge cases after
* laser hits its final point.
* @memberof Khet
* @function
* @param {String} player The player firing the laser, "red" or "blue",
* this effects which sphinx fires the laser
* @param {Array} board {@link Board}
* @returns {Number} Returns direction as a number 0-3,
* check {@link Piece} for the direction convention.
*/
Khet.getLaserEndDirection = function(player, board) {

  // Returns the initial laser object using the player specified.
  let laser = getInitialLaserStatus(player, board);

  // Sets the initial position to the laser.
  const initialPos = laser.position;

  // Sets up the current position of laser as the initial posistion.
  let currentPos = initialPos;
  
  while (laser.alive) {
    // Finds out the next position using the move function.
    currentPos = moveLaser(laser.direction, currentPos);

    if (Khet.getOnBoardStatus(currentPos)) {
      // Checks if laser is still alive at this new postion, returns true or false.
      if (getLaserStatus(laser.direction, currentPos, board)){
        laser.direction = updateDirection(laser.direction, currentPos, board);
      };
    } else {
      laser.alive = false;
    }

    /* If the laser is still alive after the check
       it returns the new direction and sets the laser to it.
    */
  }

  return laser.direction;
};


const gameBoard = Khet.getClassicBoard(Khet.getEmptyBoard());
console.log(Khet.getImageArray(gameBoard));

export default Object.freeze(Khet);

