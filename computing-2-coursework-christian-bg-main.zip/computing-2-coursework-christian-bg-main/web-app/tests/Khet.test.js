import R from "../ramda.js"; 
import Khet from "../khet.js";

describe("onBoardStatus", function (){
    it(`Given the coordinate [0, -1];
    When the check function is run;
    Then false is returned`, function(){
        const output = Khet.getOnBoardStatus([0,-1]);
        if (!R.equals(false, output)){
            throw new Error("This coord should be off the board");
        }
    });
    it(`Given the coordinate [8, 5]:
    When the check function is run;
    Then false is returned`, function(){
        const output = Khet.getOnBoardStatus([8, 5]);
        if (!R.equals(false, output)){
            throw new Error("This coord should be off the board");
        }
    });
    it(`Given the coordinate [2, 6]:
    When the check function is run;
    Then true is returned`, function(){
        const output = Khet.getOnBoardStatus([2, 6]);
        if (!R.equals(true, output)){
            throw new Error("This coord should be on the board");
        }
    });
});


describe("getLaserEndpoint", function (){
    it(`Given the player is red and the board is a classic board;
    When the end point finding function is run;
    Then the coordinate [8, 0] should be returned`, function(){
        const output = Khet.getLaserEndPoint("red", Khet.getClassicBoard(Khet.getEmptyBoard()));
        if (!R.equals([8, 0], output)){
            throw new Error(`Output was ${output}, not (8, 0)`);
        }
    });
    it(`Given the player is red and the board is a classic board,
        but modified such that the blue pyramid on (3, 2) is rotated 90 degrees CW;
        When the end point finding function is run;
        Then the coordinate [1, -1] should be returned`, function(){
        const modifiedBoard = Khet.getClassicBoard(Khet.getEmptyBoard());
        modifiedBoard[3][2]=[1, 5, 0];
        const output = Khet.getLaserEndPoint("red", modifiedBoard);
        if (!R.equals([1, -1], output)){
            throw new Error(`Output was ${output}, not (1, -1)`);
        }
    });
    it(`Given the player is red and the board is the previous modified board
    , the board is modified again by placing a Pharoh on (1, 1) to block.;
    When the end point finding function is run;
    Then the coordinate (1, 1) should be returned`, function(){
        const modifiedBoard = Khet.getClassicBoard(Khet.getEmptyBoard());
        modifiedBoard[3][2]=[1, 5, 0];
        modifiedBoard[1][1]=[1, 1, 0];
        const output = Khet.getLaserEndPoint("red", modifiedBoard);
        if (!R.equals([1, 1], output)){
            throw new Error(`Output was ${output}, not (1, 1)`);
        }
    });
})

describe("getLaserEndDirection", function (){
    it(`Given the player is red and the board is a classic board;
    When the end direction finding function is run;
    Then the direction 3 (downwards) should be returned`, function(){
        const output = Khet.getLaserEndDirection("red", Khet.getClassicBoard(Khet.getEmptyBoard()));
        if (!R.equals(3, output)){
            throw new Error(`Output was ${output}, not 3`);
        }
    });
    it(`Given the player is red and the board is a classic board,
        but modified such that the blue pyramid on (3, 2) is rotated 90 degrees CW;
        When the end direction finding function is run;
        Then the direction 2 (left) should be returned`, function(){
        const modifiedBoard = Khet.getClassicBoard(Khet.getEmptyBoard());
        modifiedBoard[3][2]=[1, 5, 0];
        const output = Khet.getLaserEndDirection("red", modifiedBoard);
        if (!R.equals(2, output)){
            throw new Error(`Output was ${output}, not 2`);
        }
    });
    it(`Given the player is red and the board is the previous modified board
    , the board is modified again by placing a Pharoh on (1, 1) to block.;
    When the end direction finding function is run;
    Then the direction 2 (left) should be returned`, function(){
        const modifiedBoard = Khet.getClassicBoard(Khet.getEmptyBoard());
        modifiedBoard[3][2]=[1, 5, 0];
        modifiedBoard[1][1]=[3, 1, 0];
        const output = Khet.getLaserEndDirection("red", modifiedBoard);
        if (!R.equals(2, output)){
            throw new Error(`Output was ${output}, not 2`);
        }
    });
});
