import R from "./ramda.js";
import Khet from "./khet.js";

const game_rows = 8;
const game_columns = 10;

const controlPanelRows = 3;
const controlPanelColumns = 3;

let currentPlayer = "red";

// Variable used to turn off clickability after a piece is clicked.
// This stops multiple pieces being selected and moved in a go.
// Variable is set back to true after the go.
let boardActivation = true;

document.documentElement.style.setProperty("--game-rows", game_rows);
document.documentElement.style.setProperty("--game-columns", game_columns);

const game_board = document.getElementById("game_board");
const control_panel = document.getElementById("control_panel");
const feedback = document.getElementById("feedback");
const next_turn_button = document.getElementById("next_turn");
next_turn_button.style.display = "none";


let gameBoard = Khet.getClassicBoard(Khet.getEmptyBoard());


const changePlayer = function (player){
    if (player === "red"){
        return "blue";
    }
    return "red";
};

const createBoard = function(board){
    game_board.style.display = "initial";
    R.range(0, game_rows).forEach(function (row_index) {
        const tr = document.createElement("tr");
        R.range(0, game_columns).forEach(function (column_index) {
            const td = document.createElement("td");
            // td.textContent = `${column_index},${row_index}`;
            const img = document.createElement("img");
            const path = Khet.getImageArray(board)[row_index][column_index];
            img.src = path;
            td.append(img);
            td.onclick = function () {
                // ply(row_index, column_index);
                console.log("initial board generated");
                if (boardActivation){
                    ply([column_index, row_index]);
                }
            };
            tr.append(td);
        });
        game_board.append(tr); 
    });
};

const removeGameboard = function (){
    for (const row of game_board.querySelectorAll('tr')) {
        row.remove();
    }
};

const redrawBoard = function(board) {
    R.range(0, game_rows).forEach(function (row_index) {
        const tr = document.createElement("tr");
        R.range(0, game_columns).forEach(function (column_index) {
            const td = document.createElement("td");
            // td.textContent = `${column_index},${row_index}`;
            const img = document.createElement("img");
            const path = Khet.getImageArray(board)[row_index][column_index];
            img.src = path;
            td.append(img);
            td.onclick = function () {
                // ply(row_index, column_index);
                console.log("initial board generated");
                if (boardActivation){
                    ply([column_index, row_index]);
                }
            };
            tr.append(td);
        });
        game_board.append(tr); 
    });
};

const ply = function (coords){
    // gets the clicked coords
    const clickedCoords = gameBoard[coords[1]][coords[0]];
    boardActivation = false;
    if (currentPlayer === "red") {
        if (gameBoard[coords[1]][coords[0]][1] === 0) {
            console.log("empty")
            return feedback.innerHTML = "nothing selected, red's move";
        }
        else if (gameBoard[coords[1]][coords[0]][2] === 0) {
            console.log("blue");
            return feedback.innerHTML = "blue piece selected, red's move";
        }
        feedback.innerHTML = "enter command";
        plyStopper(coords);
        displayControls(coords);
    } else if (currentPlayer === "blue"){
        if (gameBoard[coords[1]][coords[0]][1] === 0) {
            console.log("empty")
            return feedback.innerHTML = "nothing selected, blues's move";
        }
        else if (gameBoard[coords[1]][coords[0]][2] === 1) {
            console.log("blue");
            return feedback.innerHTML = "red piece selected, blue's move";
        }
        feedback.innerHTML = "enter command";
        plyStopper(coords);
        displayControls(coords);
        }
};

const plyStopper = function (coords){
    // gets the clicked coords
    const clickedCoords = gameBoard[coords[1]][coords[0]];
    if (currentPlayer === "red") {
        feedback.innerHTML = "enter command";
    } else if (currentPlayer === "blue"){
        feedback.innerHTML = "enter command";
    }
};

const removeControls = function () {
    for (const row of control_panel.querySelectorAll('tr')) {
        row.remove();
    };
};

const displayControls = function(coords){
    R.range(0, controlPanelRows).forEach(function (row_index) {
        const tr = document.createElement("tr");
        R.range(0, controlPanelColumns).forEach(function (column_index) {
            const td = document.createElement("td");
            // td.textContent = `${column_index},${row_index}`;
            const img = document.createElement("img");
            const path = Khet.getControlImageArray()[row_index][column_index];
            img.src = path;
            td.append(img);
            td.onclick = function () {
               // console.log([column_index,row_index]);
                checkMove(coords, [row_index, column_index]);
                removeControls();
                makeMove(coords, [column_index, row_index]);
            };
            tr.append(td);
        });
        control_panel.append(tr);
    });
};

const checkMove = function (pieceCoords, commandCoords) {
    console.log("check move function fires");
    if (gameBoard[pieceCoords[1]][pieceCoords[0]][1] === 2){
        createBoard();
//   // move up
//     } else  if (JSON.stringify(commandCoords) == JSON.stringify([1, 0])){
//     console.log(pieceCoords); 
//     if (Khet.getOnboardStatus([pieceCoords[1]-1][pieceCoords[0]])){
//         detectCellClick();
//     };
//     };
};

const makeMove = function (pieceCoords, commandCoords) {
    console.log(pieceCoords); 
    // Checks the move isnt off the board or moving to a square with another piece and moves it
    const pieceMoving = gameBoard[pieceCoords[1]][pieceCoords[0]];
    console.log("hello");
    console.log(pieceMoving);
    console.log(commandCoords);
// move up
    if (JSON.stringify(commandCoords) == JSON.stringify([1, 0])){
        console.log("yo")
        console.log(pieceCoords)
        gameBoard[pieceCoords[1]][pieceCoords[0]] = [0, 0, 0];
        gameBoard[pieceCoords[1]-1][pieceCoords[0]] = pieceMoving;
        console.log(gameBoard)
        updateBoard(pieceCoords, commandCoords, gameBoard);
// move left
    } else if (JSON.stringify(commandCoords) == JSON.stringify([0,1])){
        gameBoard[pieceCoords[1]][pieceCoords[0]] = [0, 0, 0];
        gameBoard[pieceCoords[1]][pieceCoords[0]-1] = pieceMoving;
        updateBoard(pieceCoords, commandCoords, gameBoard);
// move down
    } else if (JSON.stringify(commandCoords) == JSON.stringify([1, 2])){
        gameBoard[pieceCoords[1]][pieceCoords[0]] = [0, 0, 0];
        gameBoard[pieceCoords[1]+1][pieceCoords[0]] = pieceMoving;
        updateBoard(pieceCoords, commandCoords, gameBoard);
// move right
    } else if (JSON.stringify(commandCoords) == JSON.stringify([2, 1])){
        gameBoard[pieceCoords[1]][pieceCoords[0]] = [0, 0, 0];
        gameBoard[pieceCoords[1]][pieceCoords[0]+1] = pieceMoving;
        updateBoard(pieceCoords, commandCoords, gameBoard);
// rotateCW
    } else if ((JSON.stringify(commandCoords) == (JSON.stringify([0,0]))) || (JSON.stringify(commandCoords) == JSON.stringify([2,2]))){
    if (gameBoard[pieceCoords[1]][pieceCoords[0]][0] === 0){
        gameBoard[pieceCoords[1]][pieceCoords[0]][0] = 3;
        updateBoard(pieceCoords, commandCoords, gameBoard);
    } else {
    console.log(pieceCoords)
    console.log(gameBoard)
    gameBoard[pieceCoords[1]][pieceCoords[0]][0] = gameBoard[pieceCoords[1]][pieceCoords[0]][0]-1;
    updateBoard(pieceCoords, commandCoords, gameBoard);
    };
// rotateCCW
    } else if ((JSON.stringify(commandCoords) == JSON.stringify([0,2])) || (JSON.stringify(commandCoords) == JSON.stringify([2,0]))){
    if (gameBoard[pieceCoords[1]][pieceCoords[0]][0] === 3){
        gameBoard[pieceCoords[1]][pieceCoords[0]][0] = 0;
        updateBoard(pieceCoords, commandCoords, gameBoard);
    } else {
    gameBoard[pieceCoords[1]][pieceCoords[0]][0] = gameBoard[pieceCoords[1]][pieceCoords[0]][0]+1;
    updateBoard(pieceCoords, commandCoords, gameBoard);
    };
    };
};

const updateBoard = function(pieceCoords, commandCoords, board){
    // Changes the position of the piece within the board array
    console.log(gameBoard)

    R.range(0, game_rows).forEach(function(row_index){
        R.range(0, game_columns).forEach(function(column_index){
            const img = document.createElement("img");
            const path = Khet.getImageArray(board)[row_index][column_index];
            img.src = path;
            // Gets the cell element
            const cell = game_board.rows[row_index].cells[column_index];
            // Updates the cell's content
            const image = cell.querySelector("img");
            cell.removeChild(image);
            cell.appendChild(img);
        })
    });
    feedback.innerHTML = "laser ready to fire";
    displayLaserControls();
};

const run = function (){
    console.log(currentPlayer);
    currentPlayer = changePlayer(currentPlayer);
    console.log(currentPlayer);
    removeGameboard();
    removeControls();
    feedback.innerHTML = `${currentPlayer}'s move`
    boardActivation = true;
    redrawBoard(gameBoard);
}

const displayLaserControls = function(coords){
    control_panel.style.display= "initial";
    R.range(0, controlPanelRows).forEach(function (row_index) {
        const tr = document.createElement("tr");
        R.range(0, controlPanelColumns).forEach(function (column_index) {
            const td = document.createElement("td");
            // td.textContent = `${column_index},${row_index}`;
            const img = document.createElement("img");
            const path = Khet.getControlImageArray()[row_index][column_index];
            img.src = path;
            td.append(img);
            td.onclick = function () {
               // console.log([column_index,row_index]);
               if ((row_index === 1) && (column_index === 1)){
                const finalCoords = Khet.getLaserEndPoint(currentPlayer, gameBoard);
                if (Khet.getOnBoardStatus(finalCoords)){
                    updateBoardWithOverlay(finalCoords, gameBoard);
                    next_turn_button.style.display = "initial";
                    next_turn_button.onclick = function (){
                        next_turn_button.style.display = "none";
                        checkIfWon(finalCoords, gameBoard);
                        run();
                    };
                } else {
                    run();
                }
                };
            };
        tr.append(td);
        });
    control_panel.append(tr);
    });
};

const updateBoardWithOverlay = function(finalCoords, gameBoard){
    R.range(0, game_rows).forEach(function(row_index){
        R.range(0, game_columns).forEach(function(column_index){
            // Gets the cell element
            const cell = game_board.rows[row_index].cells[column_index];
            console.log(cell);
            console.log(finalCoords);
            // Updates the cell's content
            if (finalCoords[0] === row_index && finalCoords[1] === column_index){
                // Get the image element in the cell
                const image = cell.querySelector("img");
                // Get the PNG image URL
                const pngImageUrl = "assets/laserPoint.png";
                // Create a new image element
                const overlayImage = document.createElement("img");
                overlayImage.src = pngImageUrl;
                cell.removeChild(image)
                cell.appendChild(overlayImage);
            }
        });
    });
    checkIfWon(finalCoords, gameBoard);
};

const checkIfWon = function (finalCoords, gameBoard){
    console.log("checking if won")
    console.log(finalCoords)
    console.log(gameBoard[finalCoords[0]][finalCoords[1]][1])
    if (gameBoard[finalCoords[0]][finalCoords[1]][1] === 1) {
        feedback.innerHTML = "game won!";
        const pharohColour = gameBoard[finalCoords[0]][finalCoords[1]][2];
        alert(`${pharohColour}`+ " has lost!");
    }
    if (gameBoard[finalCoords[0]][finalCoords[1]][1] === 2) {
        feedback.innerHTML = "sphinx hit!";
    }
    if (gameBoard[finalCoords[0]][finalCoords[1]][1] === 3) {
        switch(Khet.getLaserEndDirection(currentPlayer, gameBoard)){
            case 0:
                if (gameBoard[finalCoords[1]][finalCoords[0]][0] === 2){
                    feedback.innerHTML = "anubis blocked the laser!";
                };
                feedback.innerHTML = "anubis destroyed!";
                gameBoard[finalCoords[0]][finalCoords[1]] = [0, 0, 0];
            case 1:
                if (gameBoard[finalCoords[1]][finalCoords[0]][0] === 3){
                    feedback.innerHTML = "anubis blocked the laser!";
                };
                feedback.innerHTML = "anubis destroyed!";
                gameBoard[finalCoords[0]][finalCoords[1]] = [0, 0, 0];
            case 2:
                if (gameBoard[finalCoords[1]][finalCoords[0]][0] === 0){
                    feedback.innerHTML = "anubis blocked the laser!";
                };
                feedback.innerHTML = "anubis destroyed!";
                gameBoard[finalCoords[0]][finalCoords[1]] = [0, 0, 0];
            case 3:
                if (gameBoard[finalCoords[1]][finalCoords[0]][0] === 1){
                    feedback.innerHTML = "anubis blocked the laser!";
                };
                feedback.innerHTML = "anubis destroyed!";
                gameBoard[finalCoords[0]][finalCoords[1]] = [0, 0, 0];
        };
    }
    if (gameBoard[finalCoords[0]][finalCoords[1]][1] === 5) {
        feedback.innerHTML = "pyramid hit!";
        gameBoard[finalCoords[0]][finalCoords[1]] = [0, 0, 0];
    } ;
};

createBoard(gameBoard);