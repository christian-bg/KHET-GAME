[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/uu0DCd-8)
# Computing 2 Coursework Submission.
**CID**: [02200580]

Hi Freddie,

This is my game Khet. I have included the rules as a pdf in the assets folder.

Hopefully it should be clear which icons represent each piece by looking at the classic board in the rules,
I would have made a rule book but ran out of time.

I decided to test the laser functions because I found them the most difficult to get working and having the tests were helpful.

The game works providing no illegal moves have been made - I am yet to implement all the checking functions.